import os
import time
import json
import shutil
import logging
import subprocess
import sys

# Setup paths
base_folder = os.path.dirname(os.path.abspath(__file__))
memory_file = os.path.join(base_folder, 'memory.txt')
temp_memory_file = os.path.join(base_folder, 'temp_memory.txt')
backup_folder = os.path.join(base_folder, 'Friday_backup')
backup_code_file = os.path.join(backup_folder, 'friday.py')
current_code_file = os.path.join(base_folder, 'friday.py')
update_folder = os.path.join(base_folder, 'updates')
display_file = os.path.join(base_folder, 'friday_display.pyw')
display_update = os.path.join(update_folder, 'friday_display.pyw')

# Logging setup
log_file = os.path.join(base_folder, 'friday.log')
logging.basicConfig(
    filename=log_file,
    level=logging.DEBUG,
    format='[%(asctime)s] %(levelname)s: %(message)s'
)
logger = logging.getLogger(__name__)

def check_and_restore_code():
    try:
        with open(current_code_file, 'r') as f:
            code = f.read()
        compile(code, current_code_file, 'exec')
        logger.info("Friday's code is valid.")
    except Exception as e:
        logger.error(f"Error in current code: {e}")
        if os.path.exists(backup_code_file):
            shutil.copy(backup_code_file, current_code_file)
            logger.warning("Restored friday.py from backup.")
        else:
            logger.critical("Backup file missing. Cannot restore.")

def load_memory():
    if os.path.exists(memory_file):
        with open(memory_file, 'r') as f:
            return f.read().splitlines()
    return []

def save_memory(memory):
    with open(memory_file, 'w') as f:
        f.write('\n'.join(memory))

def get_greeting():
    return "Friday is online and functioning."

def check_for_updates():
    updated = False

    update_core = os.path.join(update_folder, 'friday.py')
    if os.path.exists(update_core):
        logger.info("Update found for friday.py")
        shutil.copy(update_core, current_code_file)
        os.remove(update_core)
        updated = True

    if os.path.exists(display_update):
        logger.info("Update found for friday_display.pyw")
        shutil.copy(display_update, display_file)
        os.remove(display_update)
        updated = True

    if updated:
        logger.info("Update(s) applied. Relaunching Friday and display.")
        relaunch()
        sys.exit()

def relaunch():
    python_exec = sys.executable
    subprocess.Popen([python_exec, current_code_file])
    subprocess.Popen([python_exec, display_file], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def main():
    check_and_restore_code()
    check_for_updates()

    memory = load_memory()
    print(get_greeting())
    logger.info("Greeting displayed to user.")

    while True:
        try:
            user_input = input("You: ")
            if user_input.strip().lower() == "end session":
                print("Friday: Logging off.")
                break

            response = f"Friday: I heard you say '{user_input}'."
            print(response)
            memory.append(f"You: {user_input}")
            memory.append(response)
        except KeyboardInterrupt:
            print("\nFriday: Interrupted. Shutting down.")
            break

    save_memory(memory)
    logger.info("Session memory saved.")

if __name__ == "__main__":
    main()
