# Ollama API Change - Model Unloading

## Issue Fixed
The model unload functionality was broken because the Ollama API changed in recent versions.

## Problem
- **Old Method**: Used `/api/stop` endpoint (returned HTTP 404 - not found)
- **Symptom**: "Failed to unload model: HTTP 404" error in GUI

## Solution 
- **New Method**: Use `/api/generate` with `keep_alive: "0s"` parameter
- **How it works**: Sends an empty prompt with immediate unload instruction

## Code Change
```python
# OLD - Non-working method
payload = {"model": model_name}
response = requests.post(f"{base_url}/api/stop", json=payload)

# NEW - Working method  
payload = {
    "model": model_name,
    "prompt": "",
    "keep_alive": "0s",  # Immediately unload after this request
    "stream": False
}
response = requests.post(f"{base_url}/api/generate", json=payload)
```

## Tested With
- Ollama version: 0.11.10
- Method: Confirmed working with manual API tests

## Status
✅ **FIXED** - Model unloading now works correctly in the GUI